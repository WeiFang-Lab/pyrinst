import os
import warnings
from .__version__ import __version__

os.environ["TORCH_FORCE_NO_WEIGHTS_ONLY_LOAD"] = "1"

warnings.filterwarnings(
    "ignore",
    message=r".*torch.load.*weights_only=False",
    category=FutureWarning,
)

warnings.filterwarnings(
    "ignore",
    message=r"To copy construct from a tensor, it is recommended to use sourceTensor.clone\(\)\.detach\(\).*",
    category=UserWarning,
)

warnings.filterwarnings(
    "ignore",
    message=r"The TorchScript type system doesn't support instance-level annotations on empty non-base types in `__init__`.",
    category=UserWarning,
)